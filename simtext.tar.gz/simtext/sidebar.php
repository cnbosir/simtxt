<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="container">
    <div class="row">
<div class="col-mb-12 col-2" id="secondary" role="complementary">
            <ul class="widget-list">
                                       
<?php $this->widget('Widget_Metas_Category_List')
               ->parse('<li><a href="{permalink}">{name} <span>x{count}</span></a></li>'); ?>
                    <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                    <?php while ($pages->next()): ?>
                    <li>
                        <a<?php if ($this->is('page', $pages->slug)): ?> class="current"<?php endif; ?>
                            href="<?php $pages->permalink(); ?>"
                            title="<?php $pages->title(); ?>"><?php $pages->title(); ?></a>
                            </li>
                            
                    <?php endwhile; ?>
            </ul>
</div><!-- end #sidebar -->
