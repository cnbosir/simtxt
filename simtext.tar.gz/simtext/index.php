<?php
/**
 * 由Bosir编写
 *
 * @package Bosir
 * @author QQ：307095948
 * @version 1.2
 * @link http://typecho.org
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>

<?php $this->need('header.php'); ?>
<?php $this->need('sidebar.php'); ?>
<div class="ccol-mb-12 col-10" id="main" role="main">
    <?php while ($this->next()): ?>
        <article class="post-item" itemscope itemtype="http://schema.org/BlogPosting">
            <h2 class="post-name" itemprop="name headline">
                <a itemprop="name headline"
                   href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
            </h2>
            <div class="post-date"><?php $this->date(); ?></div>
        </article>
    <?php endwhile; ?>

    <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
    
</div><!-- end #main-->
<?php $this->need('footer.php'); ?>
