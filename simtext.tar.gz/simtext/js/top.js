// 监听滚动事件
window.addEventListener('scroll', function() {
    var scrollHeight = document.documentElement.scrollTop || document.body.scrollTop;
    var backToTopButton = document.getElementById('back-to-top');
    if (scrollHeight > 100) { // 当页面滚动超过100px时显示按钮
        backToTopButton.style.display = 'block';
    } else {
        backToTopButton.style.display = 'none';
    }
});

// 点击按钮返回顶部
document.getElementById('back-to-top').addEventListener('click', function() {
    window.scrollTo(0, 0);
});