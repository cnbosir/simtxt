<?php 
/**
 * 朋友圈
 * 
 * @package custom 
 * 
 */
?>
<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<?php $this->need('sidebar.php'); ?>

<div class="col-mb-12 col-8" id="main" role="main">
    <article class="post" itemscope itemtype="http://schema.org/BlogPosting">
        <h1 class="post-title" itemprop="name headline">
            <a itemprop="url"
               href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
        </h1>
        <div class="post-content" itemprop="articleBody">
            <?php $this->content(); ?>
    </article>
           <?php
          // 获取JSON数据
          $jsonData = file_get_contents('./output.json');
          // 将JSON数据解析为PHP数组
          $articles = json_decode($jsonData, true);
          // 对文章按时间排序（最新的排在前面）
          usort($articles, function ($a, $b) {
              return strtotime($b['time']) - strtotime($a['time']);
          });
          // 设置每页显示的文章数量
          $itemsPerPage = 30;
          // 生成文章列表
          foreach (array_slice($articles, 0, $itemsPerPage) as $article) {
          ?>
          <article class="flex comment-body my-2" style="padding: 8px 30px;background-color:#f5f1e8">

                    <div class="flex-initial w-full text-sm">
                        <div class="comment-author mb-1">
                            <div class="flex items-center">
                                <!--输出文章链接和站名-->
                                <a href="<?php echo htmlspecialchars($article['link']); ?>" target="_blank" rel="external nofollow" class="" data-ajax="false" style="text-decoration: none;font-size:18px;color:var(--main)"><?php echo htmlspecialchars($article['title']); ?></a><span class="mx-1"></span> 
                            </div>
                        </div>
 <div class="comment-content card mb-2">

                            <!--输出站名和时间-->
                           <a> <span  class="flex items-center comment-reply text-muted comment-reply-link hover:text-blue-500" ><span><?php echo htmlspecialchars($article['site_name']); ?></span>・<time class="mr-1"><?php echo htmlspecialchars($article['time']); ?></time>  </span> </a>
                            <div>
                                </div>
                    </div>
                </div>
            </article>            
         <?php } ?>
         
         
         
         </div><!-- end #main-->


<?php $this->need('footer.php'); ?>