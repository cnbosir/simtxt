<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
        </div><!-- end .row -->
        <footer id="footer" role="contentinfo">
    &copy; <?php echo date('Y'); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a><br><?php _e(' <a target="_blank" href="http://beian.miit.gov.cn">滇ICP备18004426号-2
</a><a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=51010502000019">&thinsp;浙公网安备33041102000358号</a> '); ?></br>


</footer><!-- end #footer -->
    </div>
</div><!-- end #body -->



<?php $this->footer(); ?>
</body>
</html>
