<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

// 阅读数友好化
function convert($num)
{
  if ($num >= 100000) {
    $num = round($num / 10000) . 'w';
  } else if ($num >= 10000) {
    $num = round($num / 10000, 1) . 'w';
  } else if ($num >= 1000) {
    $num = round($num / 1000, 1) . 'k';
  }
  return $num;
}
// 阅读数友好化
function Postviews($archive)
{
  $db = Typecho_Db::get();
  $cid = $archive->cid;
  if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
    $db->query('ALTER TABLE `' . $db->getPrefix() . 'contents` ADD `views` INT(10) DEFAULT 0;');
  }
  $exist = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid))['views'];
  if ($archive->is('single')) {
    $cookie = Typecho_Cookie::get('contents_views');
    $cookie = $cookie ? explode(',', $cookie) : array();
    if (!in_array($cid, $cookie)) {
      $db->query($db->update('table.contents')
        ->rows(array('views' => (int)$exist + 1))
        ->where('cid = ?', $cid));
      $exist = (int)$exist + 1;
      array_push($cookie, $cid);
      $cookie = implode(',', $cookie);
      Typecho_Cookie::set('contents_views', $cookie);
    }
  }

  if ($exist == 0) {
    echo '0';
  } else {
    $exist = convert($exist);
    echo $exist;
  }
}




function themeConfig($form)
{
    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('站点 LOGO 地址'),
        _t('在这里填入一个图片 URL 地址, 以在网站标题前加上一个 LOGO')
    );

    $form->addInput($logoUrl);

    $sidebarBlock = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'sidebarBlock',
        [
            'ShowRecentPosts'    => _t('显示最新文章'),
            'ShowRecentComments' => _t('显示最近回复'),
            'ShowCategory'       => _t('显示分类'),
            'ShowArchive'        => _t('显示归档'),
            'ShowOther'          => _t('显示其它杂项')
        ],
        ['ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive', 'ShowOther'],
        _t('侧边栏显示')
    );

    $form->addInput($sidebarBlock->multiMode());
}

function getMostVisitors($limit = 80, $masterEmail = 'myxc@live.cn')
{
    $db = Typecho_Db::get(); // 读取数据库
    $sql = $db->select('COUNT(author) AS cnt', 'author', 'url', 'mail')
        ->from('table.comments')
        // ->where('status = ?', 'approved')
        // ->where('type = ?', 'comment')
        ->where('mail != ?', $masterEmail)   //排除自己上墙
        ->group('mail')  // 按照数据发
        ->order('cnt', Typecho_Db::SORT_DESC)
        ->limit($limit);    //读取几位用户的信息
    $result = $db->fetchAll($sql);

    if ($result) {
        foreach ($result as $value) {  // 循环输出获取到的数据
            if (!$value['url']) {  // 如果用户没有url，那么就把url转化为邮箱跳转
                $value['url'] = 'mailto:' . $value['mail'];
            }
            if (!isset($mostactive)) {
    $mostactive = '';
}
            $mostactive .= '<li><a target="_blank" rel="nofollow" href="' . $value['url'] . '"><img src="https://cravatar.cn/avatar/' . md5(strtolower($value['mail'])) . '?s=36&d=&r=G"><em>' . $value['author'] . '</em><strong>+' . $value['cnt'] . '</strong></a></li>';  // 前端html结构
        }
        echo $mostactive;
    }
}

// 查询最近评论的用户——getRecentVisitors() 
function getRecentVisitors($limit = 56, $masterEmail = 'myxc@live.cn')
{
    $db = Typecho_Db::get();
    $sql = $db->select()->from('table.comments')
        ->group('mail')
        ->where('mail != ?', $masterEmail)   // 排除自己上墙
        ->limit($limit)
        ->order('created', Typecho_Db::SORT_DESC);
    $result = $db->fetchAll($sql);

    if ($result) {
        foreach ($result as $value) {
            if (!$value['url']) {
                $value['url'] = 'mailto:' . $value['mail'];
            }

            $count = $db->fetchRow(
                $db->select('COUNT(*)')
                    ->from('table.comments')
                    ->where('status = ?', 'approved')
                    ->where('mail = ?', $value['mail'])
            );
            $commentnum = $count['COUNT(*)'];

            // 修正了HTML实体编码和单引号的使用
            $mostactive .= '<li><a target="_blank" rel="nofollow" href="' . htmlspecialchars($value['url'], ENT_QUOTES, 'UTF-8') . '"><img src="https://cravatar.cn/avatar/' . md5(strtolower($value['mail'])) . '?s=36&d=&r=G"><em>' . htmlspecialchars($value['author'], ENT_QUOTES, 'UTF-8') . '</em><strong>+' . $commentnum . '</strong></a></li>';
        }
    }
    echo $mostactive; // 返回构建好的HTML字符串
}


/*
function themeFields($layout)
{
    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('站点LOGO地址'),
        _t('在这里填入一个图片URL地址, 以在网站标题前加上一个LOGO')
    );
    $layout->addItem($logoUrl);
}
*/
 