<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>
<?php $this->need('sidebar.php'); ?>
<div class="col-mb-12 col-8" id="main" role="main">
    <article class="post" itemscope itemtype="http://schema.org/BlogPosting">
    <h1 class="post-in-title">站内搜索</h1>
    <div class="category-search">
        <form method="post">
            <input type="text" name="s" class="text" placeholder="输入内容回车搜索" value="<?php echo $this->_keywords ?>" />
        </form>
    </div>
   
    <div class="category-block">
        <?php while ($this->next()): ?>
            <article class="category-post clearfix">
                <h3 class="category-post-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></h3>
                <div class="category-post-meta"><a href="<?php $this->permalink() ?>"><?php $this->date() ?></a></div>
            </article>
        <?php endwhile; ?>
    </div>
    <?php $this->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
</div><!-- end #main-->
<?php $this->need('footer.php'); ?>